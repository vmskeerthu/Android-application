package com.example.login;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public class RiderForm extends AppCompatActivity {
    DrawerLayout drawerLayout;
    TextView d_email,d_usertype;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rider_form);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        drawerLayout = findViewById(R.id.drawer_layout);
        d_email=findViewById(R.id.d_email);
        d_usertype=findViewById(R.id.d_usertype);
        Intent intent = getIntent();
        String str = intent.getStringExtra("message");
        String str1 = intent.getStringExtra("message1");
        d_email.setText(str);
        d_usertype.setText(str1);
    }
    public void ClickMenu(View view){
        Rider.openDrawer(drawerLayout);
    }
    public void ClickLogo(View view){
        Rider.closeDrawer(drawerLayout);
    }
    public void ClickHome(View view){

        recreate();
    }

    public void ClickRider(View view){
        Rider.redirectActivity(this,Rider.class);
    }
    public void ClickAboutus(View view){

        Rider.redirectActivity(this,AboutUs.class);
    }
    public void ClickLogout(View view){

        Rider.logout(this);
    }
    protected void onPause(){
        super.onPause();
        Rider.closeDrawer(drawerLayout);
    }
}