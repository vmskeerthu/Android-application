package com.example.login;

public class Information1 {
    String city,street,name,phone_no,donor;



    public Information1(){

    }
    public Information1(String City,String Street,String name,String phone_no,String donor){
        this.city=City;
        this.street=Street;
        this.name=name;
        this.phone_no=phone_no;
        this.donor=donor;

    }
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone_no() {
        return phone_no;
    }

    public void setPhone_no(String phone_no) {
        this.phone_no = phone_no;
    }
    public String getDonor() {
        return donor;
    }

    public void setDonor(String donor) {
        this.donor = donor;
    }
}

