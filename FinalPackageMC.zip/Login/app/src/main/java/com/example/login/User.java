package com.example.login;

public class User {

        String t1,t2,t3,t4;
        public User(){

        }
        public User(String t2,String t1,String t3,String t4){
                this.t2=t2;
                this.t1=t1;
                this.t3=t3;
                this.t4=t4;

        }

}
