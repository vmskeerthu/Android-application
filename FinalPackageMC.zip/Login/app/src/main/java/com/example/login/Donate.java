package com.example.login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class Donate extends AppCompatActivity {
    DrawerLayout drawerLayout;
    FirebaseAuth fAuth;
    Button button3;
    EditText EditText1,EditText2,EditText3,EditText5,EditText4,EditText6,EditText7;
    FirebaseDatabase db=FirebaseDatabase.getInstance();
    DatabaseReference root=db.getReference().child("donor");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donate);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        drawerLayout = findViewById(R.id.drawer_layout);
        fAuth=FirebaseAuth.getInstance();
        EditText1 = findViewById(R.id.Edittext1);
        EditText2 = findViewById(R.id.Edittext2);
        EditText3 = findViewById(R.id.Edittext3);
        EditText4 = findViewById(R.id.Edittext4);
        EditText5 = findViewById(R.id.Edittext5);
        EditText6 = findViewById(R.id.Edittext6);
        EditText7 = findViewById(R.id.Edittext7);
        button3 = findViewById(R.id.button3);

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String d1 = EditText1.getText().toString();
                final String d2 = EditText5.getText().toString();
                final String d3 = EditText2.getText().toString();
                final String d4 = EditText3.getText().toString();
                final String d5 = EditText4.getText().toString();
                final String d6 = EditText6.getText().toString();
                final String d7 = EditText7.getText().toString();

                if (TextUtils.isEmpty(d1)) {
                    EditText1.setError("Email is required!");
                    return;
                }
                if (TextUtils.isEmpty(d2)) {
                    EditText5.setError("Phone number is required!");
                    return;
                }
                if(d2.length()>10&&d2.length()<10){
                    EditText5.setError("Only 10 digits are allowed!");
                    return;
                }
                if (TextUtils.isEmpty(d3)) {
                    EditText2.setError("Food name is required!");
                    return;
                }
                if (TextUtils.isEmpty(d4)) {
                    EditText3.setError("Quantity is required!");
                    return;
                }
                if (TextUtils.isEmpty(d5)) {
                    EditText4.setError("Expiry hours should be mentioned!");
                    return;
                }
                if (TextUtils.isEmpty(d6)) {
                    EditText6.setError("Expiry hours should be mentioned!");
                    return;
                }
                if (TextUtils.isEmpty(d7)) {
                    EditText7.setError("Expiry hours should be mentioned!");
                    return;
                }

                HashMap<String, String> userMap = new HashMap<>();
                userMap.put("name", d1);
                userMap.put("phone_no", d2);
                userMap.put("food", d3);
                userMap.put("quantity", d4);
                userMap.put("Expiry_date", d5);
                userMap.put("Street", d6);
                userMap.put("City", d7);

                //Information info=new Information(d1,d2,d3,d4,d5,d6,d7);
                root.push().setValue(userMap);
                //root.child(d2).setValue(info);
                Intent intent = new Intent(Donate.this, Thankyou.class);
                startActivity(intent);
            }
        });
    }
    public void ClickMenu(View view){
        Donor.openDrawer(drawerLayout);
    }
    public void ClickLogo(View view){
        Donor.closeDrawer(drawerLayout);
    }
    public void ClickHome(View view){

        Donor.redirectActivity(this,Donor.class);
    }
    public void ClickDashboard(View view){

        Donor.redirectActivity(this,Dashboard.class);
    }
    public void ClickDonate(View view){

        recreate();
    }
    public void ClickAboutus(View view){

        Donor.redirectActivity(this,AboutUs.class);
    }
    public void ClickLogout(View view){

        Donor.logout(this);
    }
    protected void onPause(){
        super.onPause();
        Donor.closeDrawer(drawerLayout);
    }
}