package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Module extends AppCompatActivity {
    public ArrayList<String> garrList=new ArrayList();
    public ArrayList<String> garrAdp;
    public String City;
    public String Street;
    public String Expiry_date;
    public String food;
    public String name;
    public String phone_no;
    public String quantity;
    public String getCity(){
        return City;
    }
    public void setCity(String City){
        this.City=City;
    }
    public String getStreet(){
        return Street;
    }
    public void setStreet(String Street){
        this.Street=Street;
    }
    public String getExpiry_date(){
        return Expiry_date;
    }
    public void setExpiry_date(String Expiry_date){
        this.Expiry_date=Expiry_date;
    }
    public String getFood(){
        return food;
    }
    public void setFood(String food){
        this.food=food;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name=name;
    }
    public String getPhone_no(){
        return phone_no;
    }
    public void setPhone_no(String phone_no){
        this.phone_no=phone_no;
    }
    public String getQuantity(){
        return quantity;
    }
    public void setQuantity(String quantity){
        this.quantity=quantity;
    }
}
