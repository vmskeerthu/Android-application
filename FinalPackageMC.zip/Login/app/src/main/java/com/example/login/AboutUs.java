package com.example.login;


import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

public class AboutUs extends AppCompatActivity {
    DrawerLayout drawerLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        drawerLayout = findViewById(R.id.drawer_layout);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
    public void ClickMenu(View view){
        Donor.openDrawer(drawerLayout);
    }
    public void ClickLogo(View view){
        Donor.closeDrawer(drawerLayout);
    }
    public void ClickHome(View view){

        Donor.redirectActivity(this,Donor.class);
    }
    public void ClickDashboard(View view){

        Donor.redirectActivity(this,Dashboard.class);
    }
    public void ClickDonate(View view){
        Donor.redirectActivity(this,Donate.class);
    }
    public void ClickAboutus(View view){
        recreate();

    }
    public void ClickLogout(View view){

        Donor.logout(this);
    }
    protected void onPause(){
        super.onPause();
        Donor.closeDrawer(drawerLayout);
    }
}