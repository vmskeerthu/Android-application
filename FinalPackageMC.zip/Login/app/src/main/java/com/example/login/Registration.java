package com.example.login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class Registration extends AppCompatActivity {
    EditText registeremail,registername,registerpassword,registerconfirm;
    Button registerbutton;
    Spinner registerspinner;
    TextView login;
    FirebaseAuth fAuth;
    FirebaseDatabase db=FirebaseDatabase.getInstance();
    DatabaseReference root=db.getReference().child("users");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        login= (TextView) findViewById(R.id.textView4);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(Registration.this, Login.class);
                startActivity(intent);
            }
        });
        registeremail = findViewById(R.id.registeremail);
        registername = findViewById(R.id.registername);
        registerpassword = findViewById(R.id.registerpassword);
        registerconfirm = findViewById(R.id.registerconfirm);
        registerbutton = findViewById(R.id.button2);
        registerspinner = findViewById(R.id.registerspinner);
        fAuth=FirebaseAuth.getInstance();
        registerbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String t1=registeremail.getText().toString();
                final String t2=registername.getText().toString();
                final String t3=registerpassword.getText().toString();
                final String t4 =registerspinner.getSelectedItem().toString();
                final String t5=registerconfirm.getText().toString();

                HashMap<String,String> userMap=new HashMap<>();
                userMap.put("email",t1);
                userMap.put("name",t2);
                userMap.put("password",t3);
                userMap.put("usertype",t4);
                root.push().setValue(userMap);
                if (TextUtils.isEmpty(t1)) {
                    registeremail.setError("Email is required!");
                    return;
                }
                if (TextUtils.isEmpty(t2)) {
                    registername.setError("Name is required!");
                    return;
                }
                if (TextUtils.isEmpty(t3)) {
                    registerpassword.setError("Password is required!");
                    return;
                }
                if (TextUtils.isEmpty(t5)) {
                    registerconfirm.setError("Confirm Password is required!");
                    return;
                }
                if(!t3.equals(t5)){
                    registerconfirm.setError("Password does not match");
                    return;
                }
                if (t4.equals("Select User type")) {
                    Toast.makeText(Registration.this, "User Type is required!", Toast.LENGTH_SHORT).show();
                    return;
                }


                fAuth.createUserWithEmailAndPassword(t1,t3).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        Intent intent=new Intent(Registration.this,Login.class);
                        startActivity(intent);

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Registration.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                    }
                });

            }
        });

    }
}