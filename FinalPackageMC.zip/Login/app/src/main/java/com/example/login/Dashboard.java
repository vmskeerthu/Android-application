package com.example.login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Dashboard extends AppCompatActivity {

    DrawerLayout drawerLayout;
    private FirebaseAuth firebaseAuth;
    private FirebaseUser user;
    private String userID;
    private DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        firebaseAuth = FirebaseAuth.getInstance();
        user=firebaseAuth.getCurrentUser();
        reference= FirebaseDatabase.getInstance().getReference("users");
        userID=user.getUid();
        drawerLayout = findViewById(R.id.drawer_layout);
        final TextView proname1=(TextView) findViewById(R.id.proname);
        final TextView proemail1=(TextView)findViewById(R.id.proemail);
        final TextView propassword1=(TextView)findViewById(R.id.propassword);
        final TextView prousertype1=(TextView)findViewById(R.id.prousertype);
        reference.child(userID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User userProfile=snapshot.getValue(User.class);

                if(userProfile!=null){
                    String name1=userProfile.t2;
                    String email1=userProfile.t1;
                    String password1=userProfile.t3;
                    String usertype1=userProfile.t4;

                    proname1.setText(name1);
                    proemail1.setText(email1);
                    propassword1.setText(password1);
                    prousertype1.setText(usertype1);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Dashboard.this,"Something went wrong",Toast.LENGTH_LONG).show();
            }
        });

    }


    public void ClickMenu(View view){
        Donor.openDrawer(drawerLayout);
    }
    public void ClickLogo(View view){
        Donor.closeDrawer(drawerLayout);
    }
    public void ClickHome(View view){

        Donor.redirectActivity(this, Donor.class);
    }
    public void ClickDashboard(View view){

        recreate();
    }
    public void ClickDonate(View view){
        Donor.redirectActivity(this,Donate.class);
    }
    public void ClickAboutus(View view){

        Donor.redirectActivity(this,AboutUs.class);
    }
    public void ClickLogout(View view){

        Donor.logout(this);
    }
    protected void onPause(){
        super.onPause();
        Donor.closeDrawer(drawerLayout);
    }
}