package com.example.login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class Recipient1 extends AppCompatActivity {
    DrawerLayout drawerLayout;
    ListView listView;
    FirebaseDatabase db=FirebaseDatabase.getInstance();
    DatabaseReference root=db.getReference().child("recipient");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipient1);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        drawerLayout = findViewById(R.id.drawer_layout);

        listView=findViewById(R.id.listView);

        ArrayList<String> list=new ArrayList<>();
        ArrayAdapter adapter=new ArrayAdapter(this,R.layout.list_item,list);
        listView.setAdapter(adapter);
        DatabaseReference  reference= FirebaseDatabase.getInstance().getReference().child("donor");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list.clear();
                for(DataSnapshot snapshot:dataSnapshot.getChildren()){
                    Information info=snapshot.getValue(Information.class);
                    String a1=info.getName()+"   "+info.getPhone_no()+"   "+info.getFood()+
                            "   "+info.getExpiry_date()+"   "+info.getQuantity()+"   "+info.getCity()+"   "+info.getStreet();

                    list.add(a1);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                //final int which_item = adapter.getItem(position);
                String str=listView.getAdapter().getItem(position).toString();
                AlertDialog.Builder builder = new AlertDialog.Builder(Recipient1.this);
                builder.setMessage("Are you sure to receive the food")
                        .setPositiveButton("Accept", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                Intent intent=new Intent(getApplicationContext(),RecipientForm.class);
                                intent.putExtra("name",str);
                                startActivity(intent);
                                finish();
                            }
                        })
                        .setNegativeButton("Decline", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        });
                AlertDialog alert=builder.create();
                alert.show();
            }
        });
    }
    private void deleteRecord(String id) {
        DatabaseReference dbref = FirebaseDatabase.getInstance().getReference("donor").child(id);
        Task<Void> mTask = dbref.removeValue();
        mTask.addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(Recipient1.this, "deleted", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(Recipient1.this, "error", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void ClickMenu(View view){
        Recipient.openDrawer(drawerLayout);
    }
    public void ClickLogo(View view){
        Recipient.closeDrawer(drawerLayout);
    }
    public void ClickHome(View view){

        Recipient.redirectActivity(this,Recipient.class);
    }

    public void ClickRecipient(View view){

        recreate();
    }
    public void ClickAboutus(View view){

        Recipient.redirectActivity(this,AboutUs.class);
    }
    public void ClickLogout(View view){

        Recipient.logout(this);
    }
    protected void onPause(){
        super.onPause();
        Recipient.closeDrawer(drawerLayout);
    }

}
