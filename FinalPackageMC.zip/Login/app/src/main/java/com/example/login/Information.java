package com.example.login;

public class Information {
    //private String City;
    String City,Street,Expiry_date,food,name,phone_no,quantity;
    //private String Street;
    //private String Expiry_date;
    //private String food;
    //private String name;
    //private String phone_no;
    //private String quantity;
    public Information(){

    }
    public Information(String City,String Street,String Expiry_date,String food,String name,String phone_no,String quantity){
        this.City=City;
        this.Street=Street;
        this.Expiry_date=Expiry_date;
        this.food=food;
        this.name=name;
        this.phone_no=phone_no;
        this.quantity=quantity;

    }

    public String getCity(){
        return City;
    }
    public void setCity(String City){
        this.City=City;
    }
    public String getStreet(){
        return Street;
    }
    public void setStreet(String Street){
        this.Street=Street;
    }
    public String getExpiry_date(){
        return Expiry_date;
    }
    public void setExpiry_date(String Expiry_date){
        this.Expiry_date=Expiry_date;
    }
    public String getFood(){
        return food;
    }
    public void setFood(String food){
        this.food=food;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name=name;
    }
    public String getPhone_no(){
        return phone_no;
    }
    public void setPhone_no(String phone_no){
        this.phone_no=phone_no;
    }
    public String getQuantity(){
        return quantity;
    }
    public void setQuantity(String quantity){
        this.quantity=quantity;
    }
}
