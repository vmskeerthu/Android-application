package com.example.login;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class RecipientForm extends AppCompatActivity {
    DrawerLayout drawerLayout;
    Button rsubmit;
    FirebaseAuth fAuth;
    TextView rdonor;
    EditText rname,rphno,rcity,rstreet;
    FirebaseDatabase db=FirebaseDatabase.getInstance();
    DatabaseReference root=db.getReference().child("recipient");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipient_form);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        drawerLayout = findViewById(R.id.drawer_layout);
        fAuth= FirebaseAuth.getInstance();
        rname = findViewById(R.id.reditname);
        rphno = findViewById(R.id.reditphno);
        rcity = findViewById(R.id.reditcity);
        rstreet = findViewById(R.id.reditst);
        rdonor = findViewById(R.id.rdonor);
        rsubmit=findViewById(R.id.rsubmit);
        Intent intent = getIntent();

        rdonor.setText(intent.getExtras().getString("name"));
        rdonor.setSelected(true);

        rsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String re1 = rname.getText().toString();
                final String re2 = rphno.getText().toString();
                final String re3 = rcity.getText().toString();
                final String re4 = rstreet.getText().toString();
                final String re5 = rdonor.getText().toString();

                if (TextUtils.isEmpty(re1)) {
                    rname.setError("Name is required");
                    return;
                }
                if (TextUtils.isEmpty(re2)) {
                    rphno.setError("Phone number is required!");
                    return;
                }
                if(re2.length()>10&&re2.length()<10){
                    rphno.setError("Only 10 digits are allowed!");
                    return;
                }
                if (TextUtils.isEmpty(re3)) {
                    rcity.setError("City is required!");
                    return;
                }
                if (TextUtils.isEmpty(re4)) {
                    rstreet.setError("Street is required!");
                    return;
                }


                HashMap<String, String> userMap = new HashMap<>();
                userMap.put("name", re1);
                userMap.put("phone_no", re2);
                userMap.put("city", re3);
                userMap.put("street", re4);
                userMap.put("donor",re5);


                //Information info=new Information(d1,d2,d3,d4,d5,d6,d7);
                root.push().setValue(userMap);
                //root.child(d2).setValue(info);
                Intent intent = new Intent(RecipientForm.this, Thankyou.class);
                startActivity(intent);


            }
        });

    }
    public void ClickMenu(View view){
        Recipient.openDrawer(drawerLayout);
    }
    public void ClickLogo(View view){
        Recipient.closeDrawer(drawerLayout);
    }
    public void ClickHome(View view){

        Recipient.redirectActivity(this,Recipient.class);
    }
    public void ClickDashboard(View view){

        Recipient.redirectActivity(this,Dashboard.class);
    }
    public void ClickRecipient(View view){

        recreate();
    }
    public void ClickAboutus(View view){

        Recipient.redirectActivity(this,AboutUs.class);
    }
    public void ClickLogout(View view){

        Recipient.logout(this);
    }
    protected void onPause(){
        super.onPause();
        Recipient.closeDrawer(drawerLayout);
    }
}